import type { Lang } from './i18n';

export const stats = [
  { value: '1928', ru: 'начало истории', kz: 'тарихы басталды', en: 'history begins' },
  { value: '2071', ru: 'обучающийся в 2023–2024', kz: '2023–2024 оқу жылындағы студент', en: 'students in 2023–2024' },
  { value: '8', ru: 'направлений подготовки', kz: 'даярлау бағыты', en: 'training areas' },
  { value: '33', ru: 'клинические базы', kz: 'клиникалық база', en: 'clinical bases' },
  { value: '2021–2026', ru: 'аккредитация IQAA', kz: 'IQAA аккредитациясы', en: 'IQAA accreditation' }
];

export const specialties = [
  { slug: 'general-medicine', code: '09120100', ru: 'Лечебное дело', kz: 'Емдеу ісі', en: 'General Medicine', qualificationRu: 'Фельдшер', descRu: 'Подготовка специалистов для первичной медико-санитарной помощи, диагностики, неотложной помощи и профилактической работы.' },
  { slug: 'nursing', code: '09130100', ru: 'Сестринское дело', kz: 'Мейіргер ісі', en: 'Nursing', qualificationRu: 'Медицинская сестра общей практики', descRu: 'Практико-ориентированная подготовка медицинских сестёр для клиник, поликлиник и стационаров.' },
  { slug: 'midwifery', code: '09130200', ru: 'Акушерское дело', kz: 'Акушерлік іс', en: 'Midwifery', qualificationRu: 'Акушер', descRu: 'Подготовка специалистов по охране материнства, ведению беременности и помощи в акушерской практике.' },
  { slug: 'pharmacy', code: '09160100', ru: 'Фармация', kz: 'Фармация', en: 'Pharmacy', qualificationRu: 'Фармацевт', descRu: 'Обучение будущих фармацевтов основам лекарственного обеспечения, фармакологии и аптечной практики.' },
  { slug: 'dentistry', code: '09110100', ru: 'Стоматология', kz: 'Стоматология', en: 'Dentistry', qualificationRu: 'Зубной врач / ассистент стоматолога', descRu: 'Подготовка специалистов для стоматологических кабинетов, профилактики и ассистирования врачу.' },
  { slug: 'orthopedic-dentistry', code: '09110200', ru: 'Ортопедическая стоматология', kz: 'Ортопедиялық стоматология', en: 'Orthopedic Dentistry', qualificationRu: 'Зубной техник', descRu: 'Подготовка специалистов по изготовлению и обслуживанию ортопедических стоматологических конструкций.' },
  { slug: 'laboratory-diagnostics', code: '09140100', ru: 'Лабораторная диагностика', kz: 'Зертханалық диагностика', en: 'Laboratory Diagnostics', qualificationRu: 'Медицинский лабораторный техник', descRu: 'Обучение лабораторным исследованиям, работе с биоматериалами и современным диагностическим оборудованием.' },
  { slug: 'applied-bachelor-nursing', code: '09130100', ru: 'Прикладной бакалавр сестринского дела', kz: 'Мейіргер ісінің қолданбалы бакалавры', en: 'Applied Bachelor of Nursing', qualificationRu: 'Прикладной бакалавр', descRu: 'Расширенная программа подготовки сестринских специалистов с управленческими и клиническими компетенциями.' }
];

export const sections = [
  { slug: 'about', ru: 'О колледже', kz: 'Колледж туралы', en: 'About', descRu: 'История, миссия, администрация, музей, аккредитация и система качества.' },
  { slug: 'admissions', ru: 'Абитуриентам', kz: 'Талапкерлерге', en: 'Admissions', descRu: 'Правила приёма, документы, сроки, государственный заказ и онлайн-заявка.' },
  { slug: 'students', ru: 'Студентам', kz: 'Студенттерге', en: 'Students', descRu: 'Учёба, практика, библиотека, общежитие, спорт и психологическая служба.' },
  { slug: 'parents', ru: 'Родителям', kz: 'Ата-аналарға', en: 'Parents', descRu: 'Успеваемость, безопасность, психологическая поддержка и связь с колледжем.' },
  { slug: 'practice', ru: 'Практика', kz: 'Практика', en: 'Practice', descRu: 'Клинические базы, работодатели, социальные партнёры и трудоустройство.' },
  { slug: 'documents', ru: 'Документы', kz: 'Құжаттар', en: 'Documents', descRu: 'Аккредитация, нормативные акты, государственные услуги, сертификаты и политика качества.' },
  { slug: 'news', ru: 'Новости', kz: 'Жаңалықтар', en: 'News', descRu: 'Материалы о жизни колледжа, мероприятиях, приёме, практике и науке.' },
  { slug: 'gallery', ru: 'Галерея', kz: 'Галерея', en: 'Gallery', descRu: 'Фото колледжа, симуляционного центра, практики, событий и студенческой жизни.' },
  { slug: 'contacts', ru: 'Контакты', kz: 'Байланыс', en: 'Contacts', descRu: 'Адрес, телефон, email, карта, формы связи и контакты приёмной комиссии.' }
];

export const newsItems = [
  { slug: 'admissions-2026', date: '2026-06-01', category: 'Приём', ru: 'Приёмная кампания 2026', kz: '2026 қабылдау науқаны', en: 'Admissions campaign 2026', excerptRu: 'Информация о документах, сроках и направлениях подготовки для будущих студентов.' },
  { slug: 'student-conference', date: '2026-04-23', category: 'Наука', ru: 'Студенческая научная конференция', kz: 'Студенттік ғылыми конференция', en: 'Student scientific conference', excerptRu: 'Студенческая наука, международное сотрудничество и медицинское образование.' },
  { slug: 'clinical-practice', date: '2026-03-10', category: 'Практика', ru: 'Клиническая практика и партнёры', kz: 'Клиникалық практика және серіктестер', en: 'Clinical practice and partners', excerptRu: 'Практическая подготовка на клинических базах города и области.' },
  { slug: 'simulation-center', date: '2026-02-18', category: 'Обучение', ru: 'Симуляционный центр', kz: 'Симуляциялық орталық', en: 'Simulation center', excerptRu: 'Отработка практических навыков в безопасной образовательной среде.' },
  { slug: 'library-resources', date: '2026-01-30', category: 'Ресурсы', ru: 'Библиотека и цифровые ресурсы', kz: 'Кітапхана және цифрлық ресурстар', en: 'Library and digital resources', excerptRu: 'Учебные материалы, электронная библиотека и информационная поддержка студентов.' },
  { slug: 'student-life', date: '2025-12-20', category: 'Студенты', ru: 'Студенческая жизнь', kz: 'Студенттік өмір', en: 'Student life', excerptRu: 'Воспитательная работа, спорт, клубы, мероприятия и волонтёрские инициативы.' }
];

export const documents = [
  { titleRu: 'Аккредитация IQAA 2021–2026', category: 'Аккредитация', date: '2021–2026', url: '#' },
  { titleRu: 'Правила приёма', category: 'Абитуриентам', date: '2026', url: '#' },
  { titleRu: 'Нормативно-правовые акты', category: 'Документы', date: 'Актуально', url: '#' },
  { titleRu: 'Антикоррупционная политика', category: 'Политика', date: 'Актуально', url: '#' },
  { titleRu: 'Система управления качеством', category: 'Качество', date: 'Актуально', url: '#' },
  { titleRu: 'Государственные услуги', category: 'Услуги', date: 'Актуально', url: '#' }
];

export const gallery = [
  { titleRu: 'Кампус колледжа', category: 'Кампус', image: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=1200&q=85' },
  { titleRu: 'Лабораторная подготовка', category: 'Лаборатория', image: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=1200&q=85' },
  { titleRu: 'Клиническая практика', category: 'Практика', image: 'https://images.unsplash.com/photo-1582719471384-894fbb16e074?auto=format&fit=crop&w=1200&q=85' },
  { titleRu: 'Симуляционное обучение', category: 'Симуляция', image: 'https://images.unsplash.com/photo-1584982751601-97dcc096659c?auto=format&fit=crop&w=1200&q=85' },
  { titleRu: 'Медицинская команда', category: 'Студенты', image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?auto=format&fit=crop&w=1200&q=85' },
  { titleRu: 'Практические навыки', category: 'Обучение', image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=85' }
];

export const contacts = {
  addressRu: '120001, Республика Казахстан, г. Кызылорда, ул. Ы. Жахаева 18',
  phone: '+7 (7242) 23-05-13',
  fax: '+7 (7242) 05-13-23',
  email: 'kzmediccollege@mail.kz',
  officialSite: 'https://kzmedicalcollege.kz/',
  instagram: 'https://www.instagram.com/medcollegekzo/',
  facebook: 'https://m.facebook.com/100000861896594/'
};

export function localize<T extends { ru: string; kz: string; en: string }>(item: T, lang: Lang) {
  return item[lang] || item.ru;
}
