create table if not exists applications (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  full_name text not null,
  phone text not null,
  email text,
  specialty text,
  education_base text,
  language text,
  message text,
  status text not null default 'new'
);

create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  full_name text not null,
  phone text,
  email text,
  topic text,
  message text not null,
  status text not null default 'new'
);

alter table applications enable row level security;
alter table contact_messages enable row level security;

-- Production note:
-- Add INSERT policies for public forms only after adding spam protection.
-- Add SELECT/UPDATE policies only for authenticated admin users.
