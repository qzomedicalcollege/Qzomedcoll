# Kyzylorda Medical Higher College Platform

Полноценный Astro-проект для нового сайта Кызылординского медицинского высшего колледжа.

## Что внутри

- Astro + Tailwind CSS 4 + TypeScript
- Мультиязычность: `/ru/`, `/kz/`, `/en/`
- GitHub Pages deploy через GitHub Actions
- Главная страница
- Разделы: о колледже, специальности, абитуриентам, студентам, родителям, практика, документы, новости, галерея, контакты
- Страницы специальностей
- Страницы новостей
- Формы заявки и обратной связи
- Демо-кабинет абитуриента
- Демо-панель управления
- Supabase-ready структура

## Как загрузить на GitHub

1. Создай новый пустой репозиторий.
2. Распакуй архив.
3. Загрузи все файлы и папки в корень репозитория.
4. В настройках репозитория открой `Settings → Pages`.
5. В `Source` выбери `GitHub Actions`.
6. Открой вкладку `Actions` и дождись зелёного workflow.

Workflow сам определит название репозитория и выставит `PUBLIC_BASE_PATH`, поэтому проект должен работать в любом repo-name.

## Локальный запуск

```bash
npm install
npm run dev
```

## Сборка

```bash
npm run build
npm run preview
```

## Supabase

Формы сейчас работают в демо-режиме через localStorage. Для подключения Supabase:

1. Создай Supabase project.
2. Выполни SQL из `supabase/schema.sql`.
3. В GitHub добавь переменные окружения:
   - `PUBLIC_SUPABASE_URL`
   - `PUBLIC_SUPABASE_ANON_KEY`
4. Подключи настоящие INSERT-запросы в `ApplicationForm.astro` и `ContactForm.astro`.

Не добавляй service_role ключ в frontend.
